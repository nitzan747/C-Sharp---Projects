﻿namespace User_Interface_Console
{
    public class Program
    {   
        public static void Main()
        {
            GarageConsoleUI garageUI = new GarageConsoleUI();
            garageUI.Run();
        }
    }
}