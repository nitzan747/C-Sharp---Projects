﻿namespace User_Interface_Console
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Garage_Logic;

    public class GarageConsoleUI
    {
        private const int k_MinMenuOption = 1;
        private const int k_MaxMenuOption = 8;
        private const int k_LicenceMinLength = 6;
        private const int k_PhoneMinLength = 9;
        private const int k_ClientNameMinLength = 2;
        private Garage m_Garage;

        public Garage ConsoleGarage
        {
            get { return m_Garage; }
            set { m_Garage = value; }
        }

        private enum eMenuOptions
        {
            InsertVehicle = 1,
            ShowLicencesNum,
            ChangeVehicleStatus,
            FillMaxAirPressure,
            FuelRegularVehicle,
            ChargeElectricVehicle,
            ShowVehicleDetails,
            Exit
        }

        public void Run()
        {
            ConsoleGarage = new Garage();
            string greeting = string.Format(
                "Welcome to the Garage Manager!{0}Please follow the menu:", 
                Environment.NewLine);
            Console.WriteLine(greeting);
            ShowMenu();
        }

        public void ShowMenu()
        {
            Console.WriteLine(string.Format(
@"{0}===========================================================================
1. insert new vehicle to the garage please enter 1
2. present garage vehicles license number please enter 2
3. change status of vehicle please enter 3
4. fill air pressure of vehicle wheel to max level please enter 4
5. fill fuel of vehicle please enter 5
6. charge battery of vehicle please enter 6
7. present full details of vehicle please enter 7
8. Exit
==========================================================================={1}", 
Environment.NewLine, 
Environment.NewLine));

            chooseMenuOption();
        }

        private void chooseMenuOption()
        {
            int choosenOption = int.Parse(Console.ReadLine());
            try
            {
                while (choosenOption < k_MinMenuOption || choosenOption > k_MaxMenuOption)
                {
                    Console.WriteLine(string.Format(
                        "Please insert number between {0} to {1}.", 
                        k_MinMenuOption, 
                        k_MaxMenuOption));
                    choosenOption = int.Parse(Console.ReadLine());
                }

                selectGarageMethod((eMenuOptions)choosenOption);
            }
            catch(ValueOutOfRangeException voore)
            {
                Console.WriteLine(voore.Message);
            }
            catch (ArgumentException ae)
            {
                Console.WriteLine(ae.Message);
            }           
            catch (FormatException fe)
            {
                Console.WriteLine(fe.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                ShowMenu();
            }
        }

        private void selectGarageMethod(eMenuOptions i_ChosenOption)
        {
            switch (i_ChosenOption)
            {
                case eMenuOptions.InsertVehicle:
                    {
                        InsertVehicleToGarage();
                        break;
                    }

                case eMenuOptions.ShowLicencesNum:
                    {
                        ShowLicencesNumOfGarageVehicles();
                        break;
                    }

                case eMenuOptions.ChangeVehicleStatus:
                    {
                        ChangeGarageVehicleStatus();
                        break;
                    }

                case eMenuOptions.FillMaxAirPressure:
                    {
                        FillVehicleToMaxAirPressure();
                        break;
                    }

                case eMenuOptions.FuelRegularVehicle:
                    {
                        FuelRegularVehicle();
                        break;
                    }

                case eMenuOptions.ChargeElectricVehicle:
                    {
                        ChargeElectricVehicle();
                        break;
                    }

                case eMenuOptions.ShowVehicleDetails:
                    {
                        ShowVehicleDetails();
                        break;
                    }

                case eMenuOptions.Exit:
                    {
                        Console.WriteLine("You choose to leave the system.");
                        Environment.Exit(-1);
                        break;
                    }

                default:
                    {
                        throw new ArgumentException("Invalid option has been chosen ! "); 
                    }       
            }
        }

        public void InsertVehicleToGarage()
        {          
            string licenseNumber = getLicenseNumber();
            bool isLIcenseExist = checkIfLicenseNumberExist(licenseNumber);

            if (isLIcenseExist == true)
            {
                ConsoleGarage.ChangeVehicleStatus(licenseNumber, Garage.eVehicleStatus.InRepair);
                Console.WriteLine("Vehicle is allready in the garage and is in repair");
            }
            else
            { 
                    createNewVehicle(licenseNumber);
            }

            ShowMenu();
        }

        private string getLicenseNumber()
        {
            string licenseNumber;
            string msgToShow = string.Format(
                "Please insert vehicle license number (minimum {0} digits):", 
                k_LicenceMinLength);
            Console.WriteLine(msgToShow);           
            licenseNumber = Console.ReadLine();

            while (licenseNumber.Length < k_LicenceMinLength)
            {
                Console.WriteLine(msgToShow);
                licenseNumber = Console.ReadLine();
            }

            return licenseNumber;
        }

        private void createNewVehicle(string i_LicenseNumber)
        {
            Vehicle newVehicleToInsert;
            string clientName, clientPhone;
            List<Vehicle.QuestionForVehicleInfo> vehicleInfoQuestions;
            List<string> vehicleInfoAnswers = new List<string>();
            string vehicleTypeChosen = string.Format(
                "Please choose vehicle type: (insert the chosen index){0}{1}", 
                Environment.NewLine, 
                Garage.GetStringOfEnumValue(typeof(VehicleCreater.eVehicleType)));
            string inputVehicleType;

            do
            {
                Console.WriteLine(vehicleTypeChosen);
                inputVehicleType = Console.ReadLine();
            }
            while (VehicleCreater.IsTypeInRange(inputVehicleType) != true);

            insertClientDetails(out clientName, out clientPhone);
            newVehicleToInsert = VehicleCreater.CreateVehicle(inputVehicleType, i_LicenseNumber);
            vehicleInfoQuestions = newVehicleToInsert.GetGeneralVehicleInfo();

            foreach (Vehicle.QuestionForVehicleInfo question in vehicleInfoQuestions)
            {
                vehicleInfoAnswers.Add(GetAnswerToTheVheicleInformationRequest(question));
            }

            newVehicleToInsert.SetVehicleInfo(vehicleInfoAnswers);
            ConsoleGarage.InsertNewVehicle(clientName, clientPhone, i_LicenseNumber, newVehicleToInsert);
            Console.WriteLine("Vehicle was successfully added.");
        }

        private string GetAnswerToTheVheicleInformationRequest(Vehicle.QuestionForVehicleInfo i_Question)
        {
            string answer;
            bool isAnswerValid;

            do
            {
                Console.WriteLine(i_Question.Question);
                answer = Console.ReadLine();
                isAnswerValid = i_Question.CheckAnswerValidation(answer);
            }
            while (isAnswerValid != true);

            return answer;  
        }

        private void insertClientDetails(out string o_ClientName, out string o_ClientPhone)
        {
            do
            {
               Console.WriteLine("Please enter the vehicle's client name: ");
                o_ClientName = Console.ReadLine();
            }
            while (o_ClientName.Length <= k_ClientNameMinLength);

            do
            {
                Console.WriteLine("Please enter the vehicle's client phone number: ");
                o_ClientPhone = Console.ReadLine();
            }
            while (o_ClientPhone.Length < k_PhoneMinLength);
        }

        private bool checkIfLicenseNumberExist(string i_licenseNumber)
        {
            return ConsoleGarage.CheckIfLicenseNumberExist(i_licenseNumber);
        }

        public int getStatusToPresentTheLicenseListBy()
        {
            int selectedOption;
            string input;

            Console.WriteLine("ShowLicencesNumOfGarageVehicles");
            do
            {
                Console.WriteLine(@"To show all the vehicles in the garage press 0, 
to show vehicles in repair press 1, 
to show the fixed vehicles press 2, 
to show the paid up vehicles press 3");
                input = Console.ReadLine();
                selectedOption = int.Parse(input);
            }
            while (selectedOption > ConsoleGarage.VehicleStatusMaxValue || selectedOption < 0);

            return selectedOption;
        }

        public void ShowLicencesNumOfGarageVehicles()
        {
            int status = getStatusToPresentTheLicenseListBy();            
            List<string> licenseToPresent = ConsoleGarage.GetVehiclesLicenseListByStatus(status);

            if(licenseToPresent.Count != 0)
            {
                PrintLicenseList(licenseToPresent);
            }
            else
            {
                Console.WriteLine("There are no vehicles in this status.");
            }

            ShowMenu();
        }

         private void PrintLicenseList(List<string> i_Licenses)
        {
            StringBuilder msg = new StringBuilder();

            foreach(string license in i_Licenses)
            {
                msg.Append(license + ", ");
            }

            Console.WriteLine(msg);
        }

        public void ChangeGarageVehicleStatus()
        {            
            string license, statusTypeInput;
            bool isVehicleExist;
            int statusType;
            string msgToShow = string.Format(
                "Please insert the new vehicle status: (insert the chosen index){0}{1}", 
                Environment.NewLine, 
                Garage.GetStringOfEnumValue(typeof(Garage.eVehicleStatus)));
            license = getLicenseNumber();
            isVehicleExist = checkIfLicenseNumberExist(license);

            if (isVehicleExist == true)
            {
                do
                {
                    Console.WriteLine(msgToShow);
                    statusTypeInput = Console.ReadLine();
                    statusType = int.Parse(statusTypeInput);
                }
                while (statusType > ConsoleGarage.VehicleStatusMaxValue || statusType < ConsoleGarage.VehicleStatusMinValue);
                
                ConsoleGarage.ChangeVehicleStatus(license, (Garage.eVehicleStatus)statusType);
                Console.WriteLine("The vehicle status is now " + (Garage.eVehicleStatus)statusType + ".");
            }
            else
            {
                Console.WriteLine("There is no vehicle with this license number. ");
            }
                
            ShowMenu();
        }

        public void FillVehicleToMaxAirPressure() 
        {
            string licenseNumber;
            bool isVehicleExist;
            licenseNumber = getLicenseNumber();
            isVehicleExist = checkIfLicenseNumberExist(licenseNumber);

            if (isVehicleExist == true)
            {
                ConsoleGarage.FillVehicleToMaxAirPressure(licenseNumber);
                Console.WriteLine("The wheels has been successfully air filed.");
            }
            else
            {
                Console.WriteLine("Vehicle has not been found.");
            }

            ShowMenu();
        }

        public void FuelRegularVehicle()
        {
            string valueToFill, fuelType, errorMsg, license = getLicenseNumber();
            bool isVehicleExist;
            string msgToShow = string.Format(
                "Please insert your vehicel fuel type: (insert the chosen index){0}{1}", 
                Environment.NewLine, 
                Garage.GetStringOfEnumValue(typeof(FuelEngine.eFuelType)));
            isVehicleExist = checkIfLicenseNumberExist(license);

            if (isVehicleExist == true)
            {
                Console.WriteLine(msgToShow);
                fuelType = Console.ReadLine();
                Console.WriteLine("How much fuel you want to fill? ");
                valueToFill = Console.ReadLine();
                errorMsg = ConsoleGarage.FuelRegularVehicle(license, int.Parse(fuelType), int.Parse(valueToFill));
                if (errorMsg != null)
                {
                    Console.WriteLine(errorMsg);
                }
                else
                {
                    Console.WriteLine("Vehicle was successfully Fueled. ");
                }
            }
            else
            {
                Console.WriteLine("There is no vehicle with this license number. ");
            }

            ShowMenu();
        }

        public void ChargeElectricVehicle()
        {
            string license, minutesToCharge, errorMsg;
            bool isVehicleExist;

            license = getLicenseNumber();
            isVehicleExist = checkIfLicenseNumberExist(license);
            if (isVehicleExist == true)
            {
                Console.WriteLine("How many minutes you want to charge the vehicle? ");
                minutesToCharge = Console.ReadLine();
                errorMsg = ConsoleGarage.ChargeElectricVehicle(license, float.Parse(minutesToCharge));
                if(errorMsg != null)
                {
                    Console.WriteLine(errorMsg);
                }
                else
                {
                    Console.WriteLine("Vehicle was successfully charge. ");
                }
            }
            else
            {
                Console.WriteLine("There is no vehicle with this license number. ");
            }

            ShowMenu();
        }

        public void ShowVehicleDetails()
        {
            string license, vehicleDetails;
            bool isVehicleExist;

            license = getLicenseNumber();
            isVehicleExist = checkIfLicenseNumberExist(license);
            if(isVehicleExist == true)
            {
                vehicleDetails = ConsoleGarage.GetStringOfVehicleDetails(license);
                Console.WriteLine(vehicleDetails);
            }
            else
            {
                Console.WriteLine("There is no vehicle with this license number. ");
            }

            ShowMenu();
        }
    }
}
