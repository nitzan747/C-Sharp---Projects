﻿namespace Garage_Logic
{
    using System;

    public static class VehicleCreater
    {
        private const int k_VehicleTypeMinValue = 1;
        private const int k_VehicleTypeMaxValue = 5;

        public enum eVehicleType
        {
            Regular_MotorCycle = 1,
            Electric_Motorcycle,
            Electric_Car,
            Regular_Car,
            Truck
        }

        public static bool IsTypeInRange(string i_NumberInRange)
        {
            int numberToCheck = int.Parse(i_NumberInRange);
            bool isTypeInRange;
            if (numberToCheck > k_VehicleTypeMaxValue || numberToCheck < k_VehicleTypeMinValue)
            {
                isTypeInRange = false;
            }
            else
            {
                isTypeInRange = true;
            }

            return isTypeInRange;
        }

        public static Vehicle CreateVehicle(string i_VehicleType, string i_LicenseNumber)
        {
            Vehicle vehicleChosen;
            int converterVehicleType = int.Parse(i_VehicleType);
            eVehicleType vehicleType = (eVehicleType)converterVehicleType;
          
            switch (vehicleType)
            {
                case eVehicleType.Electric_Motorcycle:
                    {
                        vehicleChosen = createElectronicMotorCycle(i_LicenseNumber);
                        break;
                    }

                case eVehicleType.Regular_MotorCycle:
                    {
                        vehicleChosen = createRegularMotorCycle(i_LicenseNumber);
                        break;
                    }

                case eVehicleType.Electric_Car:
                    {
                        vehicleChosen = createElectronicCar(i_LicenseNumber);
                        break;
                    }

                case eVehicleType.Regular_Car:
                    {
                        vehicleChosen = createRegularCar(i_LicenseNumber);
                        break;
                    }

                case eVehicleType.Truck:
                    {
                        vehicleChosen = createTruck(i_LicenseNumber);
                        break;
                    }

                default:
                    {
                        throw new ArgumentException();
                    }
            }

            return vehicleChosen;
        }

         private static Car createRegularCar(string i_LicenseNumber)
        {
            return new Car(i_LicenseNumber, new FuelEngine(FuelEngine.eFuelType.Octan96, 60));
        }

         private static Car createElectronicCar(string i_LicenseNumber)
        {
            return new Car(i_LicenseNumber, new ElectricEngine(2.1f));
        }

        private static MotorCycle createRegularMotorCycle(string i_LicenseNumber)
        {
            return new MotorCycle(i_LicenseNumber, new FuelEngine(FuelEngine.eFuelType.Octan95, 7));
        }

        private static MotorCycle createElectronicMotorCycle(string i_LicenseNumber)
        {
            return new MotorCycle(i_LicenseNumber,  new ElectricEngine(1.2f));
        }

        private static Truck createTruck(string i_LicenseNumber)
        {
            return new Truck(i_LicenseNumber, new FuelEngine(FuelEngine.eFuelType.Soler, 120));
        }
    }
}