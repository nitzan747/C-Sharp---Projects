﻿namespace Garage_Logic
{
    using System;
    using System.Collections.Generic;

    public abstract class Vehicle
    {
        private readonly string r_LicenseNumber;
        private readonly List<Wheel> m_Wheels;
        private string m_VehicleModel;        
        private float m_EnergyLevel;        
        private Engine m_Engine;

        public Vehicle(string i_LicenseNumber, eWheelsAmount i_WheelsAmount, float i_MaxAirPressure, Engine i_Engine)
        {                       
            r_LicenseNumber = i_LicenseNumber;
            m_Wheels = new List<Wheel>();
            for(int i = 0; i < (int)i_WheelsAmount; i++)
            {
                m_Wheels.Add(new Wheel(i_MaxAirPressure));
            }

            m_Engine = i_Engine;
        }

        public enum eWheelsAmount
        {
            Two = 2,
            Four = 4,
            Six = 6
        }

        public string VehicleModel
        {
            get { return m_VehicleModel; }
            set { m_VehicleModel = value; }
        }

        public string LicenseNumber
        {
            get { return r_LicenseNumber; }
        }

        public float EnergyLevel
        {
            get { return m_EnergyLevel; }
            set { m_EnergyLevel = value; }
        }

        public Engine VehicleEngine
        {
            get { return m_Engine; }
            set { m_Engine = value; }
        }

        public List<Wheel> WheelsList
        {
            get { return m_Wheels; }
        }

        public override string ToString()
        {
            return string.Format(
                "license number: {0}, model: {1}, energy level: {2}.{3}Wheels info:{4}{5}Engine info: {6}." +
                "{7}Additional information:", 
                LicenseNumber, 
                VehicleModel, 
                EnergyLevel, 
                Environment.NewLine, 
                WheelsList[0].ToString(), 
                Environment.NewLine,
                VehicleEngine.ToString(), 
                Environment.NewLine);
        }

        public void FillAirToWheels()
        {
            float currentWheelAirpressure, airPressureNeededToAdd;

            for (int i = 0; i < WheelsList.Count; i++)
            {
                currentWheelAirpressure = WheelsList[i].CurrentAirPressure;
                airPressureNeededToAdd = WheelsList[i].MaxAirPressure - currentWheelAirpressure;
                WheelsList[i].FillingAirPressure(airPressureNeededToAdd);
            }
        }

        public virtual List<QuestionForVehicleInfo> GetGeneralVehicleInfo()
        {
            List<QuestionForVehicleInfo> questionsToUser = new List<QuestionForVehicleInfo>();
            questionsToUser.Add(new QuestionForVehicleInfo(
                QuestionForVehicleInfo.eQuestionType.StringNotEmpty, 
                "Insert vehicle's model:"));
            questionsToUser.AddRange(VehicleEngine.GetEngineInfo());
            questionsToUser.AddRange(WheelsList[0].GetWheelInfo());

            return questionsToUser;
        }
              
        public virtual List<QuestionForVehicleInfo> GetEngineInfoByEngineType()
        {
            List<QuestionForVehicleInfo> questionsToUser = VehicleEngine.GetEngineInfo();
            return questionsToUser;
        }

        public virtual void SetVehicleInfo(List<string> i_Vehiclenfo)
        {
            VehicleModel = i_Vehiclenfo[0];
            VehicleEngine.PresentEnergyAmount = float.Parse(i_Vehiclenfo[1]);
            foreach (Wheel wheel in WheelsList)
            {
                wheel.ManuFacture = i_Vehiclenfo[2];
                wheel.CurrentAirPressure = float.Parse(i_Vehiclenfo[3]);
            }

            EnergyLevel = VehicleEngine.PresentEnergyAmount / VehicleEngine.MaxEnergy;
        }

        public void UpdateEnergyLevel(float i_ValueToAdd)
        {
            VehicleEngine.FillEnergy(i_ValueToAdd);
            EnergyLevel = i_ValueToAdd / VehicleEngine.MaxEnergy;            
        }

        public class QuestionForVehicleInfo
        {
            private readonly eQuestionType r_QuestionType;
            private readonly string r_Question;
            private float? m_MinValue;
            private float? m_MaxValue;

            public QuestionForVehicleInfo(eQuestionType i_QuestionType, string i_Question)
            {
                r_QuestionType = i_QuestionType;
                r_Question = i_Question;
            }

            public QuestionForVehicleInfo(eQuestionType i_QuestionType, string i_Question, float i_MinValue, 
                float i_MaxValue)
            {
                r_QuestionType = i_QuestionType;
                r_Question = i_Question;
                m_MinValue = i_MinValue;
                m_MaxValue = i_MaxValue;
            }

            public enum eQuestionType
            {
                ValueBetweenRange,
                StringNotEmpty,
                Boolean
            }

            public eQuestionType QuestionType
            {
                get { return r_QuestionType; }
            }

            public string Question
            {
                get { return r_Question; }
            }

            public float MinValue
            {
                get
                {
                    if (m_MinValue.HasValue)
                    {
                        return m_MinValue.Value;
                    }
                    else
                    {
                        throw new Exception("The argument wasn't initialized.");
                    }
                }

                set { m_MinValue = value; }
            }

            public float MaxValue
            {
                get
                {
                    if (m_MinValue.HasValue)
                    {
                        return m_MaxValue.Value;
                    }
                    else
                    {
                        throw new Exception("The argument wasn't initialized.");
                    }
                }

                set { m_MaxValue = value; }
            }

            public bool CheckAnswerValidation(string i_Answer)
            {
                bool isAnswerValid;
                if(QuestionType == eQuestionType.Boolean)
                {
                    isAnswerValid = checkBooleanAnswerValidation(i_Answer);
                }
                else if(QuestionType == eQuestionType.StringNotEmpty)
                {
                    isAnswerValid = checkEmptyAnswerValidation(i_Answer);
                }
                else
                {
                    isAnswerValid = checkRangeAnswerValidation(i_Answer);
                }

                return isAnswerValid;
            }

            private bool checkBooleanAnswerValidation(string i_Answer)
            {
                bool isAnswerIsBolean;
                if (i_Answer == "true" || i_Answer == "false")
                {
                    isAnswerIsBolean = true;
                }
                else
                {
                    isAnswerIsBolean = false;
                }

                return isAnswerIsBolean;
            }

            private bool checkRangeAnswerValidation(string i_Answer)
            {
                bool isAnswerInRange;
                int answerByInt = int.Parse(i_Answer);

                if(answerByInt <= MaxValue && answerByInt >= MinValue)
                {
                    isAnswerInRange = true;
                }
                else
                {
                    isAnswerInRange = false;
                }

                return isAnswerInRange;
            }

            private bool checkEmptyAnswerValidation(string i_Answer)
            {
                bool isAnswerNotEmpty;
                if (i_Answer.Length != 0)
                {
                    isAnswerNotEmpty = true;
                }
                else
                {
                    isAnswerNotEmpty = false;
                }

                return isAnswerNotEmpty;
            }
        }

        public class Wheel
        {
            private readonly float r_MaxAirPressure;
            private string m_Manufacture;
            private float m_CurrentAirPressure;

            public Wheel(float i_MaxAirPressure)
            {
                r_MaxAirPressure = i_MaxAirPressure;
            }

            public float MaxAirPressure
            {
                get { return r_MaxAirPressure; }
            }

            public string ManuFacture
            {
                get { return m_Manufacture; }
                set { m_Manufacture = value; }
            }

            public float CurrentAirPressure
            {
                get { return m_CurrentAirPressure; }
                set
                {
                    if (value <= r_MaxAirPressure)
                    {
                        m_CurrentAirPressure = value;
                    }
                    else
                    {
                        throw new ArgumentException();
                    }
                }
            }

            public List<QuestionForVehicleInfo> GetWheelInfo()
            {
                List<QuestionForVehicleInfo> questionsToUser = new List<QuestionForVehicleInfo>();
                string msgForAirPressure = string.Format(
                    "Insert wheel current air pressure: (value between 0 to {0})", 
                    r_MaxAirPressure);
                
                questionsToUser.Add(new QuestionForVehicleInfo(QuestionForVehicleInfo.eQuestionType.StringNotEmpty, 
                    "Insert wheel manufacture: "));
                questionsToUser.Add(new QuestionForVehicleInfo(QuestionForVehicleInfo.eQuestionType.ValueBetweenRange, 
                    msgForAirPressure, 0, r_MaxAirPressure));

                return questionsToUser;
            }

            public bool FillingAirPressure(float i_AirToAdd)
            {
                bool isCheckFuelSucced = true;
                try
                {
                    CurrentAirPressure += i_AirToAdd;
                }               
                catch
                {
                    isCheckFuelSucced = false;
                }

                return isCheckFuelSucced;
            }

            public override string ToString()
            {
                return string.Format(
                    " manufacture: {0}, maximum air pressure: {1}, current air pressure: {2}", 
                    ManuFacture, 
                    MaxAirPressure, 
                    CurrentAirPressure);                    
            }
        }
    }
}