﻿namespace Garage_Logic
{
    using System;
    using System.Collections.Generic;

    public class Truck : Vehicle
    {
        private bool m_IsTransportingHazardousMaterials;
        private float m_CargoVolume;

        public Truck(string i_LicenseNumber, Engine i_Engine) : 
            base(i_LicenseNumber, eWheelsAmount.Six, 28, i_Engine)
        {
        }

        public bool IsTransportingHazardousMaterials
        {
            get { return m_IsTransportingHazardousMaterials; }
            set
            {
                if (value != true && value != false)
                {
                    throw new FormatException("Is transporting hazardous materials wrong input.");
                }

                m_IsTransportingHazardousMaterials = value;
            }
        }

        public float CargoVolume
        {
            get { return m_CargoVolume; }
            set { m_CargoVolume = value; }
        }

        public override void SetVehicleInfo(List<string> i_VehicleInfo)
        {
            base.SetVehicleInfo(i_VehicleInfo);
            int index = i_VehicleInfo.Count - 2;

            IsTransportingHazardousMaterials = bool.Parse(i_VehicleInfo[index]);
            CargoVolume = float.Parse(i_VehicleInfo[index + 1]);
        }

        public override List<QuestionForVehicleInfo> GetGeneralVehicleInfo()
        {
            List<QuestionForVehicleInfo> questionsToUser = new List<QuestionForVehicleInfo>();

            questionsToUser.AddRange(base.GetGeneralVehicleInfo());
            questionsToUser.Add(new QuestionForVehicleInfo(QuestionForVehicleInfo.eQuestionType.Boolean, 
                "Is the truck transporting hazardous materials? insert true / false"));
            questionsToUser.Add(new QuestionForVehicleInfo(QuestionForVehicleInfo.eQuestionType.StringNotEmpty, 
                "please insert truck's cargo volume: "));

            return questionsToUser;
        }

        public override string ToString()
        {         
            return string.Format(
                "{0} is currently driving hazardous materials : {1}, Engine Capacity: {2}.", 
                base.ToString(), 
                IsTransportingHazardousMaterials.ToString(), 
                CargoVolume);
        }
    }
}
